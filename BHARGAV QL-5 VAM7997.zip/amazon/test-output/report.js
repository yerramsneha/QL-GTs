$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/BhargavKella/eclipse-workspace/amazon/feature/amazon.feature");
formatter.feature({
  "line": 1,
  "name": "checking and verifying amazon functionality",
  "description": "",
  "id": "checking-and-verifying-amazon-functionality",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 3,
  "name": "Checking Login Functionality",
  "description": "",
  "id": "checking-and-verifying-amazon-functionality;checking-login-functionality",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "User should open Chrome Browser",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "User should Enter Url in Browser",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "User should Navigate to home page of amazon",
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "User should click on signin PushButton",
  "keyword": "Then "
});
formatter.step({
  "line": 9,
  "name": "User should enter E-mail or Phone number in Edit Box",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "User should Click on Continue in Pushbutton",
  "keyword": "And "
});
formatter.step({
  "line": 11,
  "name": "User should enter  Password in Edit Box",
  "keyword": "And "
});
formatter.step({
  "line": 12,
  "name": "User should Click on Sign in Pushbutton",
  "keyword": "And "
});
formatter.step({
  "line": 13,
  "name": "User Should Navigate Home Page",
  "keyword": "And "
});
formatter.match({
  "location": "AmazonPages.user_should_open_Chrome_Browser()"
});
formatter.result({
  "duration": 3466093300,
  "status": "passed"
});
formatter.match({
  "location": "AmazonPages.user_should_Enter_Url_in_Browser()"
});
formatter.result({
  "duration": 48119306500,
  "status": "passed"
});
formatter.match({
  "location": "AmazonPages.user_should_Navigate_to_home_page_of_amazon()"
});
formatter.result({
  "duration": 32500,
  "status": "passed"
});
formatter.match({
  "location": "AmazonPages.user_should_click_on_signin_PushButton()"
});
formatter.result({
  "duration": 2759430300,
  "status": "passed"
});
formatter.match({
  "location": "AmazonPages.user_should_enter_E_mail_or_Phone_number_in_Edit_Box()"
});
formatter.result({
  "duration": 56767500,
  "status": "passed"
});
formatter.match({
  "location": "AmazonPages.user_should_Click_on_Continue_in_Pushbutton()"
});
formatter.result({
  "duration": 1849307800,
  "status": "passed"
});
formatter.match({
  "location": "AmazonPages.user_should_enter_Password_in_Edit_Box()"
});
formatter.result({
  "duration": 51452600,
  "status": "passed"
});
formatter.match({
  "location": "AmazonPages.user_should_Click_on_Sign_in_Pushbutton()"
});
formatter.result({
  "duration": 995271800,
  "status": "passed"
});
formatter.match({
  "location": "AmazonPages.user_Should_Navigate_Home_Page()"
});
formatter.result({
  "duration": 20000,
  "status": "passed"
});
});