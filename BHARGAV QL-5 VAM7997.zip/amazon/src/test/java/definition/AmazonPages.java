package definition;



import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AmazonPages {
    WebDriver driver;

    @Given("^User should open Chrome Browser$")
    public void user_should_open_Chrome_Browser() throws Throwable {
    	System.setProperty("webdriver.chrome.driver","C:\\Users\\BhargavKella\\OneDrive - ValueMomentum, Inc\\Documents\\chromedriver_win32\\chromedriver.exe" ); 
        driver = new ChromeDriver();
        driver.manage().window().maximize();
    }

    @When("^User should Enter Url in Browser$")
    public void user_should_Enter_Url_in_Browser() throws Throwable {
        driver.get("https://www.amazon.in/");
    }

    @When("^User should Navigate to home page of amazon$")
    public void user_should_Navigate_to_home_page_of_amazon() throws Throwable {

    }

    @Then("^User should click on signin PushButton$")
    public void user_should_click_on_signin_PushButton() throws Throwable {
        driver.findElement(By.id("nav-link-accountList-nav-line-1")).click();

    }

    @Then("^User should enter E-mail or Phone number in Edit Box$")
    public void user_should_enter_E_mail_or_Phone_number_in_Edit_Box() throws Throwable {
            driver.findElement(By.id("ap_email")).sendKeys("6305175833"); 

        

    }

    @Then("^User should Click on Continue in Pushbutton$")
    public void user_should_Click_on_Continue_in_Pushbutton() throws Throwable {
        driver.findElement(By.id("continue")).click();
    }

    @Then("^User should enter  Password in Edit Box$")
    public void user_should_enter_Password_in_Edit_Box() throws Throwable {
        driver.findElement(By.id("ap_password")).sendKeys("balu1432@@"); 

    }

    @Then("^User should Click on Sign in Pushbutton$")
    public void user_should_Click_on_Sign_in_Pushbutton() throws Throwable {
        driver.findElement(By.id("signInSubmit")).click();
        System.out.println("Login Successfully");
        driver.quit();

    }

    @Then("^User Should Navigate Home Page$")
    public void user_Should_Navigate_Home_Page() throws Throwable {

    }

}