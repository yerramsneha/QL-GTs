function message() {
    window.alert("Submitted successfully !");
}

const d = new Date;
d.getDate()

function myFun() {
    document.getElementById("demoBut").innerHTML = "Submitted at " + d;
}
