function clickfun() {
    document.alert("Submitted successfully");
}
