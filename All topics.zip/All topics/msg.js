function msg()
{
  alert("Hello amazon")
 }